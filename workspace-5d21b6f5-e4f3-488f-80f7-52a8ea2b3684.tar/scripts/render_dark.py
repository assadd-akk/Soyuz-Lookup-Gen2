"""Render dark theme variant."""
from playwright.sync_api import sync_playwright
import base64
from pathlib import Path

HTML = Path('/home/z/my-project/download/soyuz-lookup.html').resolve()
PNG_1PX = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='
)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    ctx = browser.new_context(viewport={'width': 1400, 'height': 1000}, device_scale_factor=1)
    page = ctx.new_page()
    def route_handler(route):
        url = route.request.url
        if url.startswith('file://') or url.startswith('data:'):
            return route.continue_()
        if 'iili.io' in url:
            return route.fulfill(status=200, content_type='image/png', body=PNG_1PX)
        if 'bsky.social' in url or 'plc.directory' in url:
            return route.fulfill(status=200, content_type='application/json', body='{}')
        return route.continue_()
    page.route('**/*', route_handler)
    page.goto(f'file://{HTML}', wait_until='networkidle')
    page.wait_for_timeout(500)
    # force dark theme via localStorage + reload (so it persists)
    page.evaluate("localStorage.setItem('soyuz-theme','dark')")
    page.reload(wait_until='networkidle')
    page.wait_for_timeout(500)
    page.screenshot(path='/tmp/soyuz_dark.png', full_page=False)
    browser.close()
    print('dark screenshot saved')
