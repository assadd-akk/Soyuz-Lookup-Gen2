const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  // intercept outbound calls so the page doesn't actually try to authenticate
  // (we only want to see the static UI)
  await page.route('**/*', (route) => {
    const url = route.request().url();
    if (url.startsWith('file://') || url.startsWith('data:')) return route.continue();
    if (url.includes('iili.io')) {
      // serve a tiny placeholder PNG so the <img> doesn't break layout
      return route.fulfill({ status: 200, contentType: 'image/png',
        body: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64') });
    }
    if (url.includes('bsky.social') || url.includes('plc.directory')) {
      return route.fulfill({ status: 200, contentType: 'application/json', body: '{}' });
    }
    return route.continue();
  });
  await page.goto('file:///home/z/my-project/download/soyuz-lookup.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  await page.screenshot({ path: '/tmp/soyuz_initial.png', fullPage: false });
  // inject a fake profile + results to test rendering of cards
  await page.evaluate(() => {
    const results = document.getElementById('results');
    results.classList.remove('hidden');
    const sample = {
      did: 'did:plc:ragtjsm2j2vknwkz3zp4oxrd',
      handle: 'bsky.app',
      displayName: 'Bluesky',
      description: 'The official Bluesky account. Decentralized social media powered by the AT Protocol.',
      avatar: '',
      followersCount: 1234567,
      followsCount: 12,
      postsCount: 5432,
      createdAt: '2022-11-01T00:00:00.000Z',
      indexedAt: '2024-09-15T10:30:00.000Z',
      viewer: { following: false, followedBy: false, muted: false }
    };
    const didDoc = { service: [{ id: '#atproto_pds', serviceEndpoint: 'https://morel.us-east.host.bsky.network' }] };
    window.__testProfile = sample;
    window.__testDidDoc = didDoc;
  });
  // call renderProfileCard via internal function — but it's not exposed. instead, build a fake DOM
  await page.evaluate(() => {
    const results = document.getElementById('results');
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="profile-hero">
        <div class="profile-top">
          <div style="width:88px;height:88px;border-radius:50%;background:#cfd6e2;flex-shrink:0;border:3px solid #fff;"></div>
          <div class="profile-meta">
            <div class="profile-name"><span>Bluesky</span></div>
            <div class="profile-handle">@bsky.app</div>
            <p class="profile-bio">The official Bluesky account. Decentralized social media powered by the AT Protocol.</p>
            <div class="profile-tags"><span class="tag primary">You follow</span></div>
          </div>
        </div>
      </div>
      <div class="stat-row">
        <div class="stat"><div class="n">1234567</div><div class="l">Followers</div></div>
        <div class="stat"><div class="n">12</div><div class="l">Following</div></div>
        <div class="stat"><div class="n">5432</div><div class="l">Posts</div></div>
        <div class="stat"><div class="n">3y 11mo</div><div class="l">Age</div></div>
      </div>
      <div class="info-grid">
        <div class="info-cell"><div class="l">DID</div><div class="v mono">did:plc:ragtjsm2j2vknwkz3zp4oxrd</div></div>
        <div class="info-cell"><div class="l">Account Created</div><div class="v">Nov 1, 2022, 8:00 AM<br><small>Age: 3y 11mo (1460 days)</small></div></div>
        <div class="info-cell"><div class="l">PDS Proxy</div><div class="v mono">https://morel.us-east.host.bsky.network</div></div>
        <div class="info-cell"><div class="l">Location (PDS)</div><div class="v">United States · East</div></div>
        <div class="info-cell"><div class="l">Last Active</div><div class="v">Sep 15, 2024 · 1mo ago<br><small>Based on most recent post</small></div></div>
        <div class="info-cell"><div class="l">Device / Client</div><div class="v">Not exposed by AT Protocol<br><small>Bluesky posts do not carry device/client metadata by design.</small></div></div>
      </div>
    `;
    results.appendChild(card);
    // add fake grid of cards
    const grid = document.createElement('div');
    grid.className = 'grid-2';
    grid.innerHTML = `
      <div class="card">
        <div class="card-head"><h2><span class="ico">${'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="7" r="4"/><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/></svg>'}</span>Followers <span class="count-chip">500 / 1234567</span></h2></div>
        <div class="card-body flush">
          <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Sample User</div><div class="handle">@sample.bsky.social</div></div><button class="go">→</button></div>
          <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Another User</div><div class="handle">@another.bsky.social</div></div><button class="go">→</button></div>
        </div>
        <div class="load-more-wrap"><button class="load-more">Load more (showing 500 of 1234567)</button></div>
      </div>
      <div class="card">
        <div class="card-head"><h2>Following <span class="count-chip">12 / 12</span></h2></div>
        <div class="card-body flush">
          <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Followed One</div><div class="handle">@followed.bsky.social</div></div><button class="go">→</button></div>
        </div>
      </div>
    `;
    results.appendChild(grid);
  });
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/tmp/soyuz_with_results.png', fullPage: true });
  // also test mobile viewport
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: '/tmp/soyuz_mobile.png', fullPage: true });
  // toggle to light theme
  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'light');
  });
  await page.waitForTimeout(300);
  await page.setViewportSize({ width: 1400, height: 1000 });
  await page.screenshot({ path: '/tmp/soyuz_light.png', fullPage: true });
  await browser.close();
  console.log('screenshots saved');
})();
