"""Render v3 for visual verification."""
from playwright.sync_api import sync_playwright
import base64, json
from pathlib import Path

HTML = Path('/home/z/my-project/download/soyuz-lookup.html').resolve()
PNG_1PX = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=')

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    ctx = browser.new_context(viewport={'width': 1400, 'height': 1000})
    page = ctx.new_page()
    def rh(route):
        url = route.request.url
        if url.startswith('file://') or url.startswith('data:'): return route.continue_()
        if 'iili.io' in url: return route.fulfill(status=200, content_type='image/png', body=PNG_1PX)
        if 'cloudflare-dns.com' in url:
            return route.fulfill(status=200, content_type='application/dns-json',
                body='{"Status":0,"Answer":[{"name":"morel.us-east.host.bsky.network","type":1,"TTL":60,"data":"108.158.198.90"}]}')
        if 'ipapi.co' in url:
            return route.fulfill(status=200, content_type='application/json',
                body='{"ip":"108.158.198.90","city":"Ashburn","region":"Virginia","country_name":"United States","org":"Amazon.com, Inc.","asn":"AS14618","timezone":"America/New_York"}')
        if 'plc.directory' in url and '/log/' in url:
            return route.fulfill(status=200, content_type='application/json',
                body=json.dumps([{"createdAt":"2023-04-12T04:53:57.057Z","cid":"bafytest123","operation":{"type":"create"}}]))
        if 'plc.directory' in url:
            dd = {"id":"did:plc:z72i7hdynmk6r22z27h6tvur","alsoKnownAs":["at://bsky.app"],
                  "service":[{"id":"#atproto_pds","serviceEndpoint":"https://morel.us-east.host.bsky.network"}],
                  "verificationMethod":[{"id":"did:plc:z72i7hdynmk6r22z27h6tvur#atproto","type":"Multikey","publicKeyMultibase":"zQ3shXypHeVFJBgQRKgjC7jLkNqMzMzM"}],
                  "rotationKeys":["did:plc:z72i7hdynmk6r22z27h6tvur#rotation"]}
            return route.fulfill(status=200, content_type='application/json', body=json.dumps(dd))
        if 'bsky.social' in url: return route.fulfill(status=200, content_type='application/json', body='{}')
        return route.continue_()
    page.route('**/*', rh)
    page.goto(f'file://{HTML}', wait_until='networkidle')
    page.wait_for_timeout(1000)
    page.screenshot(path='/tmp/soyuz3_dark_hero.png', full_page=False)

    # inject comprehensive fake results with all new sections
    page.evaluate(r"""() => {
      const r = document.getElementById('results');
      r.classList.remove('hidden');
      r.innerHTML = '';

      // Profile
      const pc = document.createElement('div');
      pc.className = 'card';
      pc.innerHTML = `
        <div class="profile-hero">
          <div class="profile-banner" style="background: var(--grad-full);"></div>
          <div class="profile-hero-inner">
            <div class="profile-top">
              <div style="width:100px;height:100px;border-radius:50%;background:#cfd6e2;flex-shrink:0;border:4px solid var(--bg-base);"></div>
              <div class="profile-meta">
                <div class="profile-name"><span>Bluesky</span><span class="verified-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></span></div>
                <div class="profile-handle">@bsky.app</div>
                <p class="profile-bio">The official Bluesky account. Decentralized social media powered by the AT Protocol.</p>
                <div class="profile-tags"><span class="tag primary">You follow</span><span class="tag accent">Follows you</span></div>
              </div>
            </div>
          </div>
        </div>
        <div class="stat-row">
          <div class="stat"><div class="n">35484561</div><div class="l">Followers</div></div>
          <div class="stat"><div class="n">34</div><div class="l">Following</div></div>
          <div class="stat"><div class="n">907</div><div class="l">Posts</div></div>
          <div class="stat"><div class="n">3y 6mo</div><div class="l">Age</div></div>
        </div>`;
      r.appendChild(pc);

      // Trust meter
      const tm = document.createElement('div');
      tm.className = 'card';
      tm.innerHTML = `
        <div class="card-head"><h2><span class="ico">${'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19.07 4.93A10 10 0 0 1 21 12a9 9 0 0 1-9 9H3v-9a9 9 0 0 1 9-9 9 9 0 0 1 7.07 1.93z"/></svg>'}</span>Trust Analysis · AI / Scammer Radar</h2></div>
        <div class="card-body flush">
          <div class="trust-meter-wrap">
            <div class="trust-gauge">
              <svg viewBox="0 0 200 110">
                <path d="M 20 100 A 80 80 0 0 1 76 28" stroke="#ef4444" stroke-width="10" fill="none" stroke-linecap="round" opacity="0.85"/>
                <path d="M 76 28 A 80 80 0 0 1 124 28" stroke="#f59e0b" stroke-width="10" fill="none" stroke-linecap="round" opacity="0.85"/>
                <path d="M 124 28 A 80 80 0 0 1 164 64" stroke="#84cc16" stroke-width="10" fill="none" stroke-linecap="round" opacity="0.85"/>
                <path d="M 164 64 A 80 80 0 0 1 180 100" stroke="#10b981" stroke-width="10" fill="none" stroke-linecap="round" opacity="0.85"/>
                <line x1="100" y1="100" x2="140" y2="50" stroke="var(--text)" stroke-width="3" stroke-linecap="round"/>
                <circle cx="100" cy="100" r="6" fill="var(--text)"/>
              </svg>
              <div class="trust-gauge-value">
                <div class="num" style="color: var(--ok)">78</div>
                <div class="lbl">Likely Legitimate</div>
              </div>
            </div>
            <div class="trust-factors">
              <h3>AI/Scammer Likelihood: 22%</h3>
              <div class="factor-row"><div class="f-ico good"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></div><div class="f-label">Account > 2 years old</div><div class="f-impact good">+15</div></div>
              <div class="factor-row"><div class="f-ico good"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></div><div class="f-label">Healthy follower ratio</div><div class="f-impact good">+10</div></div>
              <div class="factor-row"><div class="f-ico good"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></div><div class="f-label">Verified by trusted issuer</div><div class="f-impact good">+20</div></div>
              <div class="factor-row"><div class="f-ico good"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></div><div class="f-label">Active replier (human-like)</div><div class="f-impact good">+8</div></div>
              <div class="factor-row"><div class="f-ico bad"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/></svg></div><div class="f-label">Very low engagement</div><div class="f-impact bad">-8</div></div>
            </div>
          </div>
        </div>`;
      r.appendChild(tm);

      // Posting timeline
      const tl = document.createElement('div');
      tl.className = 'card';
      const dayCounts = Array.from({length: 60}, (_, i) => Math.floor(Math.random() * 8) + (i > 40 && i < 45 ? 12 : 0));
      const maxC = Math.max(...dayCounts);
      tl.innerHTML = `
        <div class="card-head"><h2><span class="ico">${'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h4l3-9 4 18 3-9h4"/></svg>'}</span>Posting Timeline</h2><span class="count-chip">Daily · 60 days · 187 posts</span></div>
        <div class="card-body flush">
          <div class="timeline-wrap">
            <div class="timeline-bars">
              ${dayCounts.map((c, i) => `<div class="timeline-bar ${i===42?'peak':''}" style="height:${Math.max((c/maxC)*100,1)}%;${i===42?'background:var(--grad-accent);':''}" data-tip="Day ${i+1}: ${c} posts"></div>`).join('')}
            </div>
            <div class="timeline-labels"><span>Sep 1</span><span>Sep 30</span><span>Oct 30</span></div>
            <div class="chart-legend">
              <span class="li"><span class="sw" style="background:var(--grad-primary)"></span>Posts per day</span>
              <span class="li"><span class="sw" style="background:var(--grad-accent)"></span>Peak: Oct 12 (14 posts)</span>
              <span class="li">Span: 60 days since creation</span>
            </div>
          </div>
        </div>`;
      r.appendChild(tl);

      // Hourly chart
      const hc = document.createElement('div');
      hc.className = 'card';
      const hCounts = [2,1,0,0,1,2,5,8,12,15,18,14,11,9,13,17,21,16,12,8,5,4,3,2];
      const hMax = Math.max(...hCounts);
      hc.innerHTML = `
        <div class="card-head"><h2><span class="ico">${'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18M7 16l4-4 4 4 5-5"/></svg>'}</span>Posting Activity by Hour</h2><span class="count-chip">100 posts analyzed</span></div>
        <div class="card-body flush">
          <div class="chart-wrap">
            <div class="chart-bars">
              ${hCounts.map((c,h) => `<div class="chart-bar ${h===16?'peak':''}" style="height:${Math.max((c/hMax)*100,2)}%;animation-delay:${h*0.03}s" data-tip="${h}:00 UTC · ${c} posts"></div>`).join('')}
            </div>
            <div class="chart-labels"><span>00</span><span>06</span><span>12</span><span>18</span><span>23</span></div>
            <div class="chart-legend">
              <span class="li"><span class="sw" style="background:var(--grad-primary)"></span>Posting volume (UTC hour)</span>
              <span class="li"><span class="sw" style="background:var(--grad-accent)"></span>Peak: 16:00 UTC</span>
            </div>
          </div>
        </div>`;
      r.appendChild(hc);
    }""")
    page.wait_for_timeout(800)
    page.screenshot(path='/tmp/soyuz3_results.png', full_page=True)

    # mobile
    page.set_viewport_size({'width': 390, 'height': 844})
    page.screenshot(path='/tmp/soyuz3_mobile.png', full_page=True)

    # light theme
    page.evaluate("document.documentElement.setAttribute('data-theme','light')")
    page.wait_for_timeout(500)
    page.set_viewport_size({'width': 1400, 'height': 1000})
    page.screenshot(path='/tmp/soyuz3_light.png', full_page=True)

    browser.close()
    print('v3 screenshots saved')
