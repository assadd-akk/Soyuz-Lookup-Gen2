"""Render full results layout for visual verification."""
from playwright.sync_api import sync_playwright
import base64
import json
from pathlib import Path

HTML = Path('/home/z/my-project/download/soyuz-lookup.html').resolve()
PNG_1PX = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='
)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    ctx = browser.new_context(viewport={'width': 1400, 'height': 1000}, device_scale_factor=1)
    page = ctx.new_page()
    def route_handler(route):
        url = route.request.url
        if url.startswith('file://') or url.startswith('data:'):
            return route.continue_()
        if 'iili.io' in url:
            return route.fulfill(status=200, content_type='image/png', body=PNG_1PX)
        if 'bsky.social' in url or 'plc.directory' in url or 'cloudflare-dns.com' in url or 'ipapi.co' in url:
            if 'cloudflare-dns.com' in url:
                return route.fulfill(status=200, content_type='application/dns-json',
                    body='{"Status":0,"Answer":[{"name":"morel.us-east.host.bsky.network","type":1,"TTL":60,"data":"108.158.198.90"}]}')
            if 'ipapi.co' in url:
                return route.fulfill(status=200, content_type='application/json',
                    body='{"ip":"108.158.198.90","city":"Ashburn","region":"Virginia","country_name":"United States","org":"Amazon.com, Inc.","asn":"AS14618","timezone":"America/New_York"}')
            if 'plc.directory' in url and '/log/' in url:
                return route.fulfill(status=200, content_type='application/json',
                    body='[{"createdAt":"2023-04-12T04:53:57.057Z","cid":"bafytest123","operation":{"type":"create"}}]')
            if 'plc.directory' in url:
                did_doc = {
                    "id": "did:plc:z72i7hdynmk6r22z27h6tvur",
                    "alsoKnownAs": ["at://bsky.app"],
                    "service": [{"id": "#atproto_pds", "serviceEndpoint": "https://morel.us-east.host.bsky.network"}],
                    "verificationMethod": [{"id": "did:plc:z72i7hdynmk6r22z27h6tvur#atproto", "type": "Multikey", "publicKeyMultibase": "zQ3shXypHeVFJBgQRKgjC7jLkNqMzMzM"}],
                    "rotationKeys": ["did:plc:z72i7hdynmk6r22z27h6tvur#rotation"]
                }
                return route.fulfill(status=200, content_type='application/json', body=json.dumps(did_doc))
            return route.fulfill(status=200, content_type='application/json', body='{}')
        return route.continue_()
    page.route('**/*', route_handler)
    page.goto(f'file://{HTML}', wait_until='networkidle')
    page.wait_for_timeout(800)
    page.screenshot(path='/tmp/soyuz2_initial.png', full_page=False)

    # inject comprehensive fake results
    page.evaluate(r"""() => {
      const results = document.getElementById('results');
      results.classList.remove('hidden');
      results.innerHTML = '';

      // Profile hero with banner
      const profileCard = document.createElement('div');
      profileCard.className = 'card';
      profileCard.innerHTML = `
        <div class="profile-hero">
          <div class="profile-banner" style="background: linear-gradient(135deg, #1f5fff 0%, #e11d48 100%);"></div>
          <div class="profile-hero-inner">
            <div class="profile-top">
              <div style="width:96px;height:96px;border-radius:50%;background:#cfd6e2;flex-shrink:0;border:4px solid var(--surface);"></div>
              <div class="profile-meta">
                <div class="profile-name"><span>Bluesky</span><span class="verified-badge gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 9 17l-5-5"/></svg></span></div>
                <div class="profile-handle">@bsky.app</div>
                <p class="profile-bio">The official Bluesky account. Decentralized social media powered by the AT Protocol. Build social networks you can shape and control.</p>
                <div class="profile-tags">
                  <span class="tag primary">You follow</span>
                  <span class="tag accent">Follows you</span>
                  <span class="tag ok">DMs open</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="stat-row">
          <div class="stat"><div class="n">35484561</div><div class="l">Followers</div></div>
          <div class="stat"><div class="n">34</div><div class="l">Following</div></div>
          <div class="stat"><div class="n">907</div><div class="l">Posts</div></div>
          <div class="stat"><div class="n">3y 6mo</div><div class="l">Age</div></div>
        </div>
      `;
      results.appendChild(profileCard);

      // Identity + Server grid
      const gridIS = document.createElement('div');
      gridIS.className = 'grid-2';
      gridIS.innerHTML = `
        <div class="card">
          <div class="card-head"><h2><span class="ico"></span>Identity & Account</h2></div>
          <div class="card-body flush">
            <div class="info-grid">
              <div class="info-cell"><div class="l">DID</div><div class="v mono">did:plc:z72i7hdynmk6r22z27h6tvur</div></div>
              <div class="info-cell"><div class="l">Handle</div><div class="v mono">bsky.app</div></div>
              <div class="info-cell"><div class="l">Account Created</div><div class="v">Apr 12, 2023, 4:53 AM<br><small>Age: 3y 6mo (1298 days)</small></div></div>
              <div class="info-cell"><div class="l">Last Active</div><div class="v">Nov 1, 2026, 8:42 PM<br><small>2h ago · based on most recent post</small></div></div>
              <div class="info-cell"><div class="l">Indexed At</div><div class="v">Nov 1, 2026, 8:42 PM</div></div>
              <div class="info-cell"><div class="l">DID Method</div><div class="v">did:plc (Bluesky PLC)</div></div>
              <div class="info-cell"><div class="l">Account Type</div><div class="v">Organization</div></div>
              <div class="info-cell"><div class="l">DID Created</div><div class="v">Apr 12, 2023, 4:53 AM<br><small>3 operations recorded</small></div></div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h2><span class="ico"></span>Server & Hosting</h2></div>
          <div class="card-body flush">
            <div class="info-grid">
              <div class="info-cell"><div class="l">PDS Endpoint</div><div class="v mono">https://morel.us-east.host.bsky.network</div></div>
              <div class="info-cell"><div class="l">PDS Region</div><div class="v">United States · East</div></div>
              <div class="info-cell"><div class="l">PDS Hostname</div><div class="v mono">morel.us-east.host.bsky.network</div></div>
              <div class="info-cell"><div class="l">PDS IP Address</div><div class="v mono">108.158.198.90<br><small>resolved via DNS-over-HTTPS</small></div></div>
              <div class="info-cell"><div class="l">PDS Hosting Org</div><div class="v">Amazon.com, Inc.<br><small>ASN: AS14618</small></div></div>
              <div class="info-cell"><div class="l">PDS Datacenter Location</div><div class="v">Ashburn, Virginia, United States<br><small>America/New_York</small></div></div>
            </div>
            <div class="info-note"><div class="ico"></div><div><b>Important:</b> The IP, hosting org, and datacenter location shown above belong to the <b>PDS server</b> hosting this account's data — <b>NOT</b> the account owner's IP or location.</div></div>
          </div>
        </div>
      `;
      results.appendChild(gridIS);

      // Posting activity card with chart
      const paCard = document.createElement('div');
      paCard.className = 'card';
      paCard.innerHTML = `
        <div class="card-head"><h2><span class="ico"></span>Posting Activity Pattern</h2><span class="count-chip">100 posts analyzed</span></div>
        <div class="card-body flush">
          <div class="chart-wrap">
            <div class="chart-bars">
              ${Array.from({length:24}, (_,h) => {
                const counts = [2,1,0,0,1,2,5,8,12,15,18,14,11,9,13,17,21,16,12,8,5,4,3,2];
                const max = Math.max(...counts);
                const pct = (counts[h]/max)*100;
                const peak = h === 16;
                return `<div class="chart-bar ${peak?'peak':''}" style="height:${Math.max(pct,2)}%" data-tip="${h}:00 UTC · ${counts[h]} posts"></div>`;
              }).join('')}
            </div>
            <div class="chart-labels"><span>00</span><span>06</span><span>12</span><span>18</span><span>23</span></div>
            <div class="chart-legend">
              <span class="li"><span class="sw" style="background:var(--primary)"></span>Posting volume (UTC hour)</span>
              <span class="li"><span class="sw" style="background:var(--accent)"></span>Peak hour: 16:00 UTC</span>
            </div>
          </div>
          <div class="kv-summary">
            <div class="kv-item"><div class="k">Estimated Timezone</div><div class="vv">UTC-8<small>inferred from sleep/wake pattern</small></div></div>
            <div class="kv-item"><div class="k">Original Posts</div><div class="vv">62<small>62% of analyzed</small></div></div>
            <div class="kv-item"><div class="k">Replies</div><div class="vv">28<small>28% of analyzed</small></div></div>
            <div class="kv-item"><div class="k">Reposts</div><div class="vv">10<small>10% of analyzed</small></div></div>
            <div class="kv-item"><div class="k">Posts with Media</div><div class="vv">45<small>images, video, or cards</small></div></div>
            <div class="kv-item"><div class="k">Posts Analyzed</div><div class="vv">100<small>last ~100 posts</small></div></div>
          </div>
        </div>
      `;
      results.appendChild(paCard);
    }""")
    page.wait_for_timeout(500)
    page.screenshot(path='/tmp/soyuz2_results.png', full_page=True)

    # Mobile
    page.set_viewport_size({'width': 390, 'height': 844})
    page.screenshot(path='/tmp/soyuz2_mobile.png', full_page=True)

    # Light theme desktop
    page.evaluate("document.documentElement.setAttribute('data-theme','light')")
    page.wait_for_timeout(300)
    page.set_viewport_size({'width': 1400, 'height': 1000})
    page.screenshot(path='/tmp/soyuz2_light.png', full_page=True)

    # Dark theme top (just initial page)
    page.evaluate("localStorage.setItem('soyuz-theme','dark'); document.documentElement.setAttribute('data-theme','dark')")
    page.wait_for_timeout(300)
    page.screenshot(path='/tmp/soyuz2_dark_hero.png', full_page=False)

    browser.close()
    print('screenshots saved')
