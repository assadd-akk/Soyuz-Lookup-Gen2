"""Headless-render smoke test for the Soyuz Lookup single-file app."""
import base64
from pathlib import Path
from playwright.sync_api import sync_playwright

HTML = Path('/home/z/my-project/download/soyuz-lookup.html').resolve()
PNG_1PX = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='
)

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(viewport={'width': 1400, 'height': 1000}, device_scale_factor=1)
        page = ctx.new_page()

        # intercept network: stub logos + bsky/plc calls so UI renders without network
        def route_handler(route):
            url = route.request.url
            if url.startswith('file://') or url.startswith('data:'):
                return route.continue_()
            if 'iili.io' in url:
                return route.fulfill(status=200, content_type='image/png', body=PNG_1PX)
            if 'bsky.social' in url or 'plc.directory' in url:
                return route.fulfill(status=200, content_type='application/json', body='{}')
            return route.continue_()
        page.route('**/*', route_handler)

        page.goto(f'file://{HTML}', wait_until='networkidle')
        page.wait_for_timeout(800)
        page.screenshot(path='/tmp/soyuz_initial.png', full_page=False)

        # inject a fake results DOM so we can see the cards layout
        page.evaluate(r"""() => {
          const results = document.getElementById('results');
          results.classList.remove('hidden');
          const card = document.createElement('div');
          card.className = 'card';
          card.innerHTML = `
            <div class="profile-hero">
              <div class="profile-top">
                <div style="width:88px;height:88px;border-radius:50%;background:#cfd6e2;flex-shrink:0;border:3px solid #fff;"></div>
                <div class="profile-meta">
                  <div class="profile-name"><span>Bluesky</span></div>
                  <div class="profile-handle">@bsky.app</div>
                  <p class="profile-bio">The official Bluesky account. Decentralized social media powered by the AT Protocol.</p>
                  <div class="profile-tags"><span class="tag primary">You follow</span><span class="tag accent">Follows you</span></div>
                </div>
              </div>
            </div>
            <div class="stat-row">
              <div class="stat"><div class="n">1234567</div><div class="l">Followers</div></div>
              <div class="stat"><div class="n">12</div><div class="l">Following</div></div>
              <div class="stat"><div class="n">5432</div><div class="l">Posts</div></div>
              <div class="stat"><div class="n">3y 11mo</div><div class="l">Age</div></div>
            </div>
            <div class="info-grid">
              <div class="info-cell"><div class="l">DID</div><div class="v mono">did:plc:ragtjsm2j2vknwkz3zp4oxrd</div></div>
              <div class="info-cell"><div class="l">Account Created</div><div class="v">Nov 1, 2022, 8:00 AM<br><small>Age: 3y 11mo (1460 days)</small></div></div>
              <div class="info-cell"><div class="l">PDS Proxy</div><div class="v mono">https://morel.us-east.host.bsky.network</div></div>
              <div class="info-cell"><div class="l">Location (PDS)</div><div class="v">United States · East</div></div>
              <div class="info-cell"><div class="l">Last Active</div><div class="v">Sep 15, 2024 · 1mo ago<br><small>Based on most recent post</small></div></div>
              <div class="info-cell"><div class="l">Device / Client</div><div class="v">Not exposed by AT Protocol<br><small>Bluesky posts do not carry device/client metadata by design.</small></div></div>
              <div class="info-cell"><div class="l">Indexed At</div><div class="v">Sep 15, 2024, 10:30 AM</div></div>
              <div class="info-cell"><div class="l">Handle</div><div class="v mono">bsky.app</div></div>
            </div>
          `;
          results.appendChild(card);

          const grid = document.createElement('div');
          grid.className = 'grid-2';
          grid.innerHTML = `
            <div class="card">
              <div class="card-head"><h2><span class="ico"></span>Followers <span class="count-chip">500 / 1234567</span></h2></div>
              <div class="card-body flush">
                <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Sample User</div><div class="handle">@sample.bsky.social</div></div><button class="go">→</button></div>
                <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Another User</div><div class="handle">@another.bsky.social</div></div><button class="go">→</button></div>
              </div>
              <div class="load-more-wrap"><button class="load-more">Load more (showing 500 of 1234567)</button></div>
            </div>
            <div class="card">
              <div class="card-head"><h2><span class="ico"></span>Following <span class="count-chip">12 / 12</span></h2></div>
              <div class="card-body flush">
                <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Followed One</div><div class="handle">@followed.bsky.social</div></div><button class="go">→</button></div>
              </div>
            </div>
          `;
          results.appendChild(grid);

          const gridLM = document.createElement('div');
          gridLM.className = 'grid-2';
          gridLM.innerHTML = `
            <div class="card">
              <div class="card-head"><h2><span class="ico"></span>Links on Account <span class="count-chip">3</span></h2></div>
              <div class="card-body flush">
                <div class="link-row"><div class="ico">[link]</div><div class="link-content"><div class="link-title">Bluesky Homepage</div><a class="link-url">https://bsky.app</a><div class="link-source">profile description</div></div></div>
                <div class="link-row"><div class="ico">[link]</div><div class="link-content"><a class="link-url">https://github.com/bluesky-social</a><div class="link-source">post facet · 5×</div></div></div>
              </div>
            </div>
            <div class="card">
              <div class="card-head"><h2><span class="ico"></span>Accounts Mentioned (Recent Posts) <span class="count-chip">7</span></h2></div>
              <div class="card-body flush">
                <div class="user-row"><div style="width:38px;height:38px;border-radius:50%;background:#cfd6e2"></div><div class="meta"><div class="name">Mentioned User</div><div class="handle">@mentioned.bsky.social</div></div><span class="tag">12×</span><button class="go">→</button></div>
              </div>
            </div>
          `;
          results.appendChild(gridLM);
        }""")
        page.wait_for_timeout(400)
        page.screenshot(path='/tmp/soyuz_with_results.png', full_page=True)

        # mobile viewport
        page.set_viewport_size({'width': 390, 'height': 844})
        page.screenshot(path='/tmp/soyuz_mobile.png', full_page=True)

        # light theme desktop
        page.evaluate("document.documentElement.setAttribute('data-theme','light')")
        page.wait_for_timeout(300)
        page.set_viewport_size({'width': 1400, 'height': 1000})
        page.screenshot(path='/tmp/soyuz_light.png', full_page=True)

        browser.close()
        print('screenshots saved')

if __name__ == '__main__':
    main()
